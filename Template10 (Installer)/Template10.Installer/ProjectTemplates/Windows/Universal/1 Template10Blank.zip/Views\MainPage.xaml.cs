using System;
using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
